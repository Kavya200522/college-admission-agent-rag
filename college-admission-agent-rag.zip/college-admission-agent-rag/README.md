# 🎓 College Admission Agent using RAG (Retrieval-Augmented Generation)

This project is a smart AI-powered assistant that helps prospective students with accurate, up-to-date information about college admissions using IBM Watsonx and Retrieval-Augmented Generation (RAG).

🔗 **Live Project Link**: [Open in IBM Cloud](https://dataplatform.cloud.ibm.com/wx/agents/d00a9124-39b9-42ef-ba0b-e9aae7be97b9?project_id=5ac14dad-3edc-4657-a1fb-ddeccd835968&context=wx)

## 💡 Features
- Retrieve admission policy and eligibility info
- Answer FAQs and deadlines instantly
- Provide course selection help
- Available 24/7 to improve accessibility

## 📁 Structure
- `README.md` - Overview
- `project_structure.md` - Tools and methods used
- `instructions.md` - Deployment guide
- `data/` - Input knowledge base file
